package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskCreatedSuccessfully() {
        Task task = new Task("12345", "Study", "Complete module four assignment");

        assertEquals("12345", task.getTaskId());
        assertEquals("Study", task.getName());
        assertEquals("Complete module four assignment", task.getDescription());
    }

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Study", "Complete module four assignment");
        });
    }

    @Test
    void testTaskIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Study", "Complete module four assignment");
        });
    }

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete module four assignment");
        });
    }

    @Test
    void testNameCannotBeLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "ThisNameIsWayTooLong1", "Complete module four assignment");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Study", null);
        });
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                "12345",
                "Study",
                "This description is intentionally longer than fifty characters."
            );
        });
    }
}