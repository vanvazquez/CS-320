package TaskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public boolean addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID must be unique");
        }

        tasks.put(task.getTaskId(), task);
        return true;
    }

    public boolean deleteTask(String taskId) {
        return tasks.remove(taskId) != null;
    }

    public boolean updateTask(String taskId, String name, String description) {
        Task task = tasks.get(taskId);

        if (task == null) {
            return false;
        }

        task.setName(name);
        task.setDescription(description);

        return true;
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}