package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskWithUniqueId() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Study", "Complete module four assignment");

        assertTrue(service.addTask(task));
        assertEquals(task, service.getTask("12345"));
    }

    @Test
    void testCannotAddDuplicateTaskId() {
        TaskService service = new TaskService();

        Task task1 = new Task("12345", "Study", "Complete module four assignment");
        Task task2 = new Task("12345", "Workout", "Complete afternoon workout");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    void testCannotAddNullTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(null);
        });
    }

    @Test
    void testDeleteTaskById() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Study", "Complete module four assignment");

        service.addTask(task);

        assertTrue(service.deleteTask("12345"));
        assertNull(service.getTask("12345"));
    }

    @Test
    void testDeleteFailsWhenTaskDoesNotExist() {
        TaskService service = new TaskService();

        assertFalse(service.deleteTask("99999"));
    }

    @Test
    void testUpdateTaskFieldsById() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Study", "Complete module four assignment");

        service.addTask(task);

        assertTrue(service.updateTask("12345", "Workout", "Complete afternoon workout"));

        Task updatedTask = service.getTask("12345");

        assertEquals("Workout", updatedTask.getName());
        assertEquals("Complete afternoon workout", updatedTask.getDescription());
    }

    @Test
    void testUpdateFailsWhenTaskDoesNotExist() {
        TaskService service = new TaskService();

        assertFalse(service.updateTask("99999", "Workout", "Complete afternoon workout"));
    }

    @Test
    void testUpdateNameCannotBeNull() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Study", "Complete module four assignment");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("12345", null, "Complete afternoon workout");
        });
    }

    @Test
    void testUpdateDescriptionCannotBeNull() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Study", "Complete module four assignment");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("12345", "Workout", null);
        });
    }
}