package AppointmentService;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public boolean addAppointment(Appointment appointment) {
        if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID must be unique");
        }

        appointments.put(appointment.getAppointmentId(), appointment);
        return true;
    }

    public boolean deleteAppointment(String appointmentId) {
        return appointments.remove(appointmentId) != null;
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}