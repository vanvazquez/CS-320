package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    void testAppointmentCreatedSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Doctor appointment");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentIdCannotBeLongerThanTenCharacters() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor appointment");
        });
    }

    @Test
    void testAppointmentDateCannotBeInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Doctor appointment");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                "12345",
                futureDate,
                "This description is intentionally longer than fifty characters."
            );
        });
    }
}