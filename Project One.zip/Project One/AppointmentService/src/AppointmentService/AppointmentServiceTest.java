package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAppointmentWithUniqueId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Doctor appointment");

        assertTrue(service.addAppointment(appointment));
        assertEquals(appointment, service.getAppointment("12345"));
    }

    @Test
    void testCannotAddDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment1 = new Appointment("12345", futureDate, "Doctor appointment");
        Appointment appointment2 = new Appointment("12345", futureDate, "Dentist appointment");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    void testCannotAddNullAppointment() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    @Test
    void testDeleteAppointmentById() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Doctor appointment");

        service.addAppointment(appointment);

        assertTrue(service.deleteAppointment("12345"));
        assertNull(service.getAppointment("12345"));
    }

    @Test
    void testDeleteFailsWhenAppointmentDoesNotExist() {
        AppointmentService service = new AppointmentService();

        assertFalse(service.deleteAppointment("99999"));
    }
}