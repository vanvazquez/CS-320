package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testContactCreatedSuccessfully() {
        Contact contact = new Contact("12345", "Van", "Vazquez", "1234567890", "123 Main Street");

        assertEquals("12345", contact.getContactId());
        assertEquals("Van", contact.getFirstName());
        assertEquals("Vazquez", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Van", "Vazquez", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testContactIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Van", "Vazquez", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testFirstNameCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Vazquez", "1234567890", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "VanAlexandr", "Vazquez", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testLastNameCannotBeNullOrLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", null, "1234567890", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "VazquezLugo", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testPhoneCannotBeNullAndMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "Vazquez", null, "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "Vazquez", "12345", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "Vazquez", "12345678901", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "Vazquez", "12345abcde", "123 Main Street");
        });
    }

    @Test
    void testAddressCannotBeNullOrLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "Vazquez", "1234567890", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Van", "Vazquez", "1234567890",
                    "1234567890123456789012345678901");
        });
    }
}