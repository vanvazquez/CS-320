package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void testAddContactWithUniqueId() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Van", "Vazquez", "1234567890", "123 Main Street");

        assertTrue(service.addContact(contact));
        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    void testCannotAddDuplicateContactId() {
        ContactService service = new ContactService();

        Contact contact1 = new Contact("12345", "Van", "Vazquez", "1234567890", "123 Main Street");
        Contact contact2 = new Contact("12345", "Alex", "Lugo", "0987654321", "456 Main Street");

        assertTrue(service.addContact(contact1));
        assertFalse(service.addContact(contact2));
    }

    @Test
    void testDeleteContactById() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Van", "Vazquez", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertTrue(service.deleteContact("12345"));
        assertNull(service.getContact("12345"));
    }

    @Test
    void testUpdateContactFieldsById() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Van", "Vazquez", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertTrue(service.updateContact("12345", "Alex", "Lugo", "0987654321", "456 Main Street"));

        Contact updatedContact = service.getContact("12345");

        assertEquals("Alex", updatedContact.getFirstName());
        assertEquals("Lugo", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Main Street", updatedContact.getAddress());
    }

    @Test
    void testUpdateFailsWhenContactDoesNotExist() {
        ContactService service = new ContactService();

        assertFalse(service.updateContact("99999", "Alex", "Lugo", "0987654321", "456 Main Street"));
    }

    @Test
    void testDeleteFailsWhenContactDoesNotExist() {
        ContactService service = new ContactService();

        assertFalse(service.deleteContact("99999"));
    }
}